import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.Charset;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

//import com.mysql.jdbc.Statement;

//import felhasznalokJDBC.Felhasznalo;

//import osztalyzatokOOPSingleton.Tanulo;

public class Jegyzetek {
/*
 * *****File-ba írás******
 * 
	FileOutputStream fs=new FileOutputStream(fajlNev,false);  false-újfile//true-hozzáfűzés
	OutputStreamWriter out=new OutputStreamWriter(fs,"UTF-8");
	out.write();
	
	FileWriter fw=new FileWriter(fajlnev,Charset.forName("UTF-8"),true); 
	fw.write();
	
	****File ból olvasás*******
	
	BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(fajlnev),"UTF-8"));     
	
	
	for (int i=0; i<tanulok.length; i++) {
			
			String sor = br.readLine();
			String[] csvSor = sor.split(elvalaszto);
			
			Tanulo tanuloObj = new Tanulo(csvSor[0],
							Integer.parseInt(csvSor[1]),
							Integer.parseInt(csvSor[2]),
							Integer.parseInt(csvSor[3]));
			
			tanulok[i] = tanuloObj;					
			
		}


	*Miért nem statikusan használjuk a file és adat kezelésT? 1 példányhoz jó csak a statikus
	
	
	
	Kollekciók:
	
Map nem bejárható--> szótár kulcs-érték pár (kulcs csak egyszer szerepelhet)

for (Map.Entry<String, Double> tanulo: tanulokAtlaga.entrySet()) {
			System.out.println(tanulo.getKey()+" átlaga: "+ tanulo.getValue());
		}


Set (halmaz) bejárható,de nem lehet indexen keresztül (egy elem csak egyzser szerepelhet)

		for (String csapat : csapatok) {
		System.out.println(csapat);
		}
		
		for (Iterator<String> i =csapatok.iterator();i.hasNext();) {
			if(i.next().startsWith("Ba")) {
				i.remove();
			}
			

		halmaz.addAll(halmaz2); // unió kézés   removeAll kivonás retainAll metszet
		
		HashSet- véletlen szerű sorrend
		LinkedHashset /megmarad a beviteli sorrend, láncolt halmaz
		TreeSet rendezett halmaz (Halmaz átadható paraméterként) növekvő szám sorrend vagy abc




***************GUI-s rész***********
			public void windowClosing(WindowEvent e) {
			
				//JOptionPane a leggyakrabban használt dialógus ablak
				//https://docs.oracle.com/javase/tutorial/uiswing/components/dialog.html
				
				Object[] opciok= {"igen","nem"};
				ImageIcon ikon=new ImageIcon("kilepes.png");
				int valasz=JOptionPane.showOptionDialog(frmSzamkitalalos,"Biztos ki akar lépni?",
						"Kilépés",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE,ikon,opciok,opciok[1]);
				if(valasz==JOptionPane.YES_OPTION) {
					//frmSzamkitalalos.dispose();//csak egy ablak bezárása 
					System.exit(0);// kilépés
				}

Esemény átirányítás:
	frmSzamkitalalos.dispatchEvent(new WindowEvent(frmSzamkitalalos, WindowEvent.WINDOW_CLOSING));	


			private DefaultListModel<String> ListModel;
JList feltöltése: 
		//1. tömb vagy kollekció feltöltése a megjelenítendő elemekkel
		//2. Modell létrehozása és adatok átemelése az adatszerkezetből(1.pont)
		//3. Modell hozzárendelés a komponenshez
			ListModel=new DefaultListModel<String>();
			lstTortenet.setModel(ListModel);
			
			
			
			
*******************SQL:********************
	private static Connection kapcsolat;
	private static PreparedStatement sqlUtasitas; //SQL injection kivédése miatt kell a preparedStatement és nem a sima Statement

try {
			String connectionString ="jdbc:mysql://localhost:3306/felhasznalokDB?autoReconnect=true&useSSL=false";//jdbc:mysql://localhost:3306/?user=root      ? után + utasítások
			kapcsolat=DriverManager.getConnection(connectionString,"root","nagyd32");//felhasználó + jelszó sql adatbázis motorhoz
			
			
		} catch (Exception e) {
			throw new SQLException("A csatlakozás sikertelen"+e.getMessage());
		}		




SQL CRUD műveletek
 * 
	//felhasznaló tábla oszlopai: ID, Felhasznalonev, jelszo, RegisztrácioDatum
	public static void ujFelhasznalo(Felhasznalo felhasznalo) throws SQLException {
		try {
			sqlUtasitas=kapcsolat.prepareStatement("INSERT INTO felhasznalo(Felhasznalonev, jelszo) VALUES(?,?)",Statement.RETURN_GENERATED_KEYS);//? paramétereket jelöli
			sqlUtasitas.setString(1, felhasznalo.getFelhasznaloNev());//1 paraméter ? 
			sqlUtasitas.setString(2, felhasznalo.getJelszo());
			
			//sql utasítás végrehajtása 3 módon lehetséges:
			//executeQuery()--> select esetén használjuk, ResultSet típusban szolgáltatja az eredményeket
			//executeUpdate()--> insert/update/delete utasításokat futtat és int eredményt szolgáltat
			//execute() -->bármilyen utasítás lehet (select/insert/delete/update) logikai eredménnyel tér vissza, 
			//				ha ResultSet(select) eredményünk van akkor true,többire false int eredmény  
			
			sqlUtasitas.executeUpdate();
			ResultSet res=sqlUtasitas.getGeneratedKeys();
			if(res.next()) {
				felhasznalo.setId(res.getInt(1));
			}
			
			sqlUtasitas.clearParameters();
			
			sqlUtasitas=kapcsolat.prepareStatement("select * from felhasznalo where ID=?");
			sqlUtasitas.setInt(1, felhasznalo.getId());
			res=sqlUtasitas.executeQuery();
			if(res.next()) {
				LocalDate datum=res.getTimestamp("RegisztrácioDatum").toLocalDateTime().toLocalDate();
				felhasznalo.setRegisztacioDatuma(datum);
			}
			sqlUtasitas.clearParameters();
		} catch (Exception e) {
			if(e.getMessage().toLowerCase().contains("duplicate")) {
				throw new SQLException("Létező felhasználó név!"+e.getMessage());
			}else {
				
				throw new SQLException("A felhasználó felvitele sikertelen!"+e.getMessage());
			}	
		}

*/
	
	/*StreamApi + lambda kifejezések:
	 * StreamApi műveleteknél, ha nem lambda kifejezéseket használunk ,hogyan lehet még megadni a feltételt?
	 * 
	 * termekek.stream().mapToInt(x -> x.getAr()).sum());
	 */
	
	
	
	
}
