package teszt;

public class Foprogram {

	public static void main(String[] args) {
		osztalyTeszt teszt=new osztalyTeszt("Nagy Dávid", 34);
		Teszt_2 teszt2=new Teszt_2(teszt, "Férfi");
		
		System.out.println(teszt2.getSzemely());

	}

}
