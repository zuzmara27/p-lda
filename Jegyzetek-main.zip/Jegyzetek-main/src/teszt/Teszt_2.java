package teszt;

public class Teszt_2 {
	
	private osztalyTeszt szemely;
	private String nem;
	public Teszt_2(osztalyTeszt szemely, String nem) {
		this.szemely = szemely;
		this.nem = nem;
	}
	public osztalyTeszt getSzemely() {
		return szemely;
	}
	public void setSzemely(osztalyTeszt szemely) {
		this.szemely = szemely;
	}
	public String getNem() {
		return nem;
	}
	public void setNem(String nem) {
		this.nem = nem;
	}
	

}
